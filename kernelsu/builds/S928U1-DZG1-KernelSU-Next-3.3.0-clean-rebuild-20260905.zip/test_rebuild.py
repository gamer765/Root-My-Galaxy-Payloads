#!/usr/bin/env python3
"""Static regression checks; these do not substitute for a phone test."""
import unittest
from pathlib import Path

import inspect_embedded_elf as embedded

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source" / "userspace" / "ksud"
BASELINE_ASSETS = {
    "083070d5f1f154fd14b43c94325390ab58a60473ad6306288280a9e576dc9250",
    "4d60ab3f5a59ebb2ca863f2f514e6924401b581e9b64f602665c008177626651",
    "36b977ecf13424091f3c8c6bb47e98bd318d7908e2070e417efe81a6460cdef6",
}


class RebuildChecks(unittest.TestCase):
    def test_late_load_is_synchronous(self):
        source = (SOURCE / "src" / "late_load.rs").read_text()
        self.assertNotIn("utils::daemonize(", source)
        self.assertNotIn("Command::new(\"am\")", source)

    def test_staging_order(self):
        source = (SOURCE / "src" / "late_load.rs").read_text()
        stage = source.index("utils::stage_daemon_from(")
        load = source.index("ksuinit::load_module(")
        reset = source.index("utils::reset_std()")
        finish = source.index("utils::finish_install(")
        self.assertLess(stage, load)
        self.assertLess(load, reset)
        self.assertLess(reset, finish)
        self.assertNotIn("utils::install(", source)

    def test_finish_install_does_not_recopy_daemon(self):
        source = (SOURCE / "src" / "utils.rs").read_text()
        body = source.split("pub fn finish_install(", 1)[1].split("pub fn install(", 1)[0]
        self.assertNotIn("std::fs::copy", body.split("if let Some(libadbroot)", 1)[0])
        self.assertNotIn("std::fs::write", body)
        self.assertIn("restorecon::lsetfilecon", body)

    def test_all_input_assets_match_baseline(self):
        paths = list((SOURCE / "bin" / "aarch64").iterdir())
        self.assertEqual(len(paths), 3)
        self.assertEqual({embedded.sha256(p.read_bytes()) for p in paths}, BASELINE_ASSETS)

    def test_final_embedded_assets_match_baseline(self):
        daemon = ROOT / "ksud-e3q-S928USQS6DZG1-kdp-ksun-3.3.0-clean-20260905"
        report = embedded.scan(daemon)
        self.assertEqual(len(report["assets"]), 3)
        self.assertEqual({a["sha256"] for a in report["assets"]}, BASELINE_ASSETS)
        self.assertTrue(all(a["machine"] == 183 for a in report["assets"]))

    def test_elf_inspector_rejects_invalid_input(self):
        with self.assertRaises(ValueError):
            embedded.rodata(b"not an ELF")


if __name__ == "__main__":
    unittest.main(verbosity=2)
