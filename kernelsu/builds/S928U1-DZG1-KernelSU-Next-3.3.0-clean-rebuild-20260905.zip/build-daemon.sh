#!/usr/bin/env bash
# Rebuild only userspace, retaining the baseline DZG1 embedded module verbatim.
set -euo pipefail
task_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
ksun_source="$task_dir/source"
: "${ANDROID_NDK_ROOT:?Set ANDROID_NDK_ROOT to Android NDK r29}"
ndk_llvm="$ANDROID_NDK_ROOT/toolchains/llvm/prebuilt/linux-x86_64"
export PATH="$ndk_llvm/bin:$PATH"
export LIBCLANG_PATH="$ndk_llvm/lib"
export CLANG_PATH="$ndk_llvm/bin/clang"
export CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER="$ndk_llvm/bin/aarch64-linux-android26-clang"
export CC_aarch64_linux_android="$CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER"
export CXX_aarch64_linux_android="$ndk_llvm/bin/aarch64-linux-android26-clang++"
export AR_aarch64_linux_android="$ndk_llvm/bin/llvm-ar"
export RANLIB_aarch64_linux_android="$ndk_llvm/bin/llvm-ranlib"
export BINDGEN_EXTRA_CLANG_ARGS_aarch64_linux_android="--sysroot=$ndk_llvm/sysroot -I$ndk_llvm/sysroot/usr/include/aarch64-linux-android -I$ndk_llvm/sysroot/usr/include"
export KSU_BUILD_VERSION_CODE=33214
export KSU_BUILD_VERSION_NAME=3.3.0
# Every invocation gets an empty output tree; cached downloaded dependencies
# may be reused, but no compiled crate, build script or embedded asset is reused.
export CARGO_TARGET_DIR
CARGO_TARGET_DIR=$(mktemp -d "$task_dir/cargo-clean.XXXXXX")
artifact="$task_dir/ksud-e3q-S928USQS6DZG1-kdp-ksun-3.3.0-clean-20260905"
[[ ! -e "$artifact" ]] || { echo "Refusing to overwrite $artifact" >&2; exit 1; }
module="$ksun_source/userspace/ksud/bin/aarch64/android14-6.1_kernelsu.ko"
expected=083070d5f1f154fd14b43c94325390ab58a60473ad6306288280a9e576dc9250
actual=$(sha256sum "$module")
[[ "${actual%% *}" = "$expected" ]] || { echo 'Incorrect DZG1 module input' >&2; exit 1; }
echo "Clean target directory: $CARGO_TARGET_DIR"
rustc --version
cargo --version
"$ndk_llvm/bin/clang" --version
cargo build --offline --locked --release --target aarch64-linux-android \
  --manifest-path "$ksun_source/userspace/ksud/Cargo.toml"
cp "$CARGO_TARGET_DIR/aarch64-linux-android/release/ksud" "$artifact"
chmod 755 "$artifact"
python3 "$task_dir/inspect_embedded_elf.py" "$artifact" --expected-module "$module"
stat -c '%s %n' "$artifact"
sha256sum "$artifact"
