# DZG1 KernelSU Next 3.3.0 — clean daemon rebuild

Built 2026-09-05 for the user's SM-S928U1 on S928U1UES6DZG1.
This is a **new, device-untested test daemon**, not a confirmed fix for rc=13.
The working GitHub daemon and live support manifest were not changed.

## Output

`ksud-e3q-S928USQS6DZG1-kdp-ksun-3.3.0-clean-20260905`

- Exact file size for a support manifest: **5509824 bytes**.
- SHA-256: `0adb8c27f5426f1749a34fdc775b5e9cbb97456f6197a62a711548ff77962530`.
- ELF64 AArch64 Android PIE, interpreter `/system/bin/linker64`.
- KernelSU Next version metadata: `3.3.0`, code `33214`.
- Intended running kernel: `6.1.145-android14-11-33419968-abS928USQS6DZG1`.
- Only the userspace daemon and its linked Rust dependencies were compiled.
  The kernel module was deliberately **not rebuilt or stripped**.

## Baseline identity and corrections to prior advice

The baseline is the 5,401,816-byte file named
`ksud-e3q-S928USQS6DZG1-kdp-ksun-3.3.0` in
`gamer765/Root-My-Galaxy-Payloads`, SHA-256
`6210355f18552308c98dcf9fd96bcdb18c0d9c8bbb38f81e0bf0595943e660d0`.
The local baseline's Git blob ID `0ff65f854734b9c2904d7df505241e4a95340bb9`
matches the remote path checked during this rebuild.

The earlier 3,737,048-byte build report did not establish successful use on
the phone. It is not used as this rebuild's baseline. Neither the repeated
rc=13 report nor the earlier log establishes that stripping or a kernel ABI
mismatch caused the failure.

The failed debugless rebuild source still called `utils::daemonize(false)`
before loading. That function double-forks and lets its original process exit
before the actual load has finished. A waiting installer can therefore check
the control interface too early. The same source also lacked the Samsung
pre-load daemon staging and post-load finish-install split. These are concrete
source differences; they do not prove the complete cause of the phone failure.

## Changes in this rebuild

- Start from local Git tag `v3.3.0`, commit
  `3b18216f71df189ab3d1b1ce0bdb21be1268e771`, in a separate checkout.
- Restore the userspace staging portion of the previously supplied Samsung
  compatibility patch: rename the staged daemon before module loading, then
  finish labels and assets afterward.
- Keep late-load synchronous so the caller waits for completion.
- Keep automatic Manager force-stop/relaunch disabled, as in the previous
  Samsung staging patch.
- Add explicit build-time version inputs so the included source archive can
  retain `3.3.0` / `33214` without a `.git` directory.
- Use the locked dependency set and a newly created, empty Cargo target directory.
  No compiled crate or old embedded-asset build output was reused.
- Use Android NDK r29 (Clang 21.0.0), API 26 userspace target, Rust 1.98.1.
  The source release profile is `opt-level=z`, LTO, one codegen unit and
  ordinary daemon symbol stripping. Kernel module bytes remain untouched.

All three embedded assets were independently decompressed from the working
daemon and the rebuilt daemon. Their complete bytes have identical hashes:

| Asset | Uncompressed bytes | SHA-256 |
| --- | ---: | --- |
| `android14-6.1_kernelsu.ko` | 5808440 | `083070d5f1f154fd14b43c94325390ab58a60473ad6306288280a9e576dc9250` |
| `busybox` | 1710600 | `4d60ab3f5a59ebb2ca863f2f514e6924401b581e9b64f602665c008177626651` |
| `bootctl` | 154248 | `36b977ecf13424091f3c8c6bb47e98bd318d7908e2070e417efe81a6460cdef6` |

The daemon itself is not byte-identical to the baseline. This test intentionally
retains module debug data; size reduction should be a separate change after
the rebuilt userspace has been tested successfully.

## Validation and limitations

- Fresh offline, locked release build: successful.
- All three embedded binary hashes match the baseline; no extra binary asset.
- Six static regression checks: passed (asset hashes and source loading order).
- ELF architecture, interpreter, dynamic dependencies and version outputs checked.
- `git diff --check` and build-script syntax check passed.
- No Android emulator, phone execution, module insertion, or boot test was run.
- No exploit, kernel module code, firmware, or boot image was changed.

The CLI follows the prior v3.3.0 staged loader interface. It does not add the
newer `--ephemeral` option. Use the same APK/installer flow that works with the
baseline; a different loader interface needs separate review. This build also
does not add an embedded `ksuinit` boot-patching binary that was absent from
the working daemon. Its purpose is the existing late-load workflow, not
flashing a patched boot image.

## Support feed and testing

`support-entry.json` is an **unpublished entry to append**, not a replacement
for the whole `targets-v3.json`. Its distinct daemon URL will not work until
the new daemon is uploaded to that exact path. No upload was performed in
this task. Keep the original entry and artifact unchanged.

After publishing a separate test entry, refresh the support feed and explicitly
select the `DZG1 clean rebuild 20260905` profile. Automatic selection can choose
a different profile with the same model and three-part kernel version. The
daemon's expected download size must be `5509824`.

Only test on DZG1, not DZH3. Keep your working daemon available. A device test
can replace the installed `/data/adb/ksud` through the normal staging flow even
though the GitHub files remain separate. Preserve the full application log if
it fails; do not infer the cause from rc=13 alone.

## Included build materials

- `source.tar.gz`: exact userspace sources, UAPI headers, license, lockfiles and
  original embedded assets used here (not a full Samsung kernel source tree).
- `daemon-userspace.patch`: changes against the pinned v3.3.0 checkout.
- `build-daemon.sh`: rebuilds with a fresh output directory and refuses to
  overwrite an existing output daemon.
- `inspect_embedded_elf.py`: offline embedded-asset inspection/verification.
- `test_rebuild.py`, build and verification logs, and `SHA256SUMS`.

For another rebuild, use a fresh directory, unpack `source.tar.gz` there, and
copy `build-daemon.sh` and `inspect_embedded_elf.py` beside `source/`. Configure
Android NDK r29 and Rust 1.98.1 with the `aarch64-linux-android` standard library.
Set `ANDROID_NDK_ROOT` and make `cargo` available on PATH. The script builds
offline; dependencies must already be cached (or fetched with `cargo fetch
--locked --manifest-path source/userspace/ksud/Cargo.toml` before running it).
Run `bash build-daemon.sh`. Matching inputs do not by themselves establish
physical-device compatibility or byte-for-byte reproducibility of the daemon.
