#!/usr/bin/env python3
"""Inspect raw-DEFLATE ELF assets without executing a daemon or modifying inputs."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import zlib


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def rodata(data):
    if data[:6] != b"\x7fELF\x02\x01":
        raise ValueError("Expected little-endian ELF64")
    shoff = struct.unpack_from("<Q", data, 40)[0]
    entsize, count, names_index = struct.unpack_from("<HHH", data, 58)
    headers = [struct.unpack_from("<IIQQQQIIQQ", data, shoff + i * entsize)
               for i in range(count)]
    names_header = headers[names_index]
    names = data[names_header[4]:names_header[4] + names_header[5]]
    for h in headers:
        name = names[h[0]:].split(b"\0", 1)[0]
        if name == b".rodata":
            return h[4], h[4] + h[5]
    raise ValueError("No .rodata section")


def scan(path, out_dir=None):
    data = path.read_bytes()
    start, end = rodata(data)
    records = []
    offset = start
    while offset < end:
        # Reserved DEFLATE block type cannot contain a valid asset.
        if (data[offset] >> 1) & 3 == 3:
            offset += 1
            continue
        try:
            prefix = zlib.decompressobj(-15).decompress(data[offset:offset + 256], 16)
        except zlib.error:
            offset += 1
            continue
        if not prefix.startswith(b"\x7fELF\x02\x01"):
            offset += 1
            continue
        decoder = zlib.decompressobj(-15)
        try:
            result = decoder.decompress(data[offset:end], 32 * 1024 * 1024)
        except zlib.error:
            offset += 1
            continue
        if not decoder.eof:
            offset += 1
            continue
        consumed = end - offset - len(decoder.unused_data)
        record = {"offset": offset, "compressed_bytes": consumed,
                  "bytes": len(result), "sha256": sha256(result),
                  "elf_type": struct.unpack_from("<H", result, 16)[0],
                  "machine": struct.unpack_from("<H", result, 18)[0]}
        if out_dir is not None:
            target = out_dir / f"asset-{offset:x}.elf"
            with target.open("xb") as stream:
                stream.write(result)
            record["extracted_path"] = str(target.resolve())
        records.append(record)
        offset += consumed
    return {"daemon": str(path.resolve()), "bytes": len(data),
            "sha256": sha256(data), "assets": records}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("daemon", type=Path)
    parser.add_argument("--extract-dir", type=Path)
    parser.add_argument("--expected-module", type=Path)
    args = parser.parse_args()
    if args.extract_dir:
        args.extract_dir.mkdir(parents=True, exist_ok=False)
    report = scan(args.daemon, args.extract_dir)
    if args.expected_module:
        expected = sha256(args.expected_module.read_bytes())
        modules = [a for a in report["assets"] if a["elf_type"] == 1]
        if len(modules) != 1 or modules[0]["sha256"] != expected:
            raise SystemExit("FAIL: embedded module is not the sole expected module")
        report["expected_module_matches"] = True
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
